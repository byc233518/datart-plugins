## [Experimental] AntV GG

- [x] datart version: **1.0.0**
- [x] status: **experimental**

![AntVGG](./experiment-antvg2-chart.png)
