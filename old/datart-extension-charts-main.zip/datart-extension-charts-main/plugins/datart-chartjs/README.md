## [Experimental] ChartJS

- [x] datart version: **1.0.0**
- [x] status: **experimental**

![ChartJS Sample](./experiment-antvg2-chart.png)

## 使用说明
[ChartJS](https://www.chartjs.org/) official site.

### 数据区域配置

### 样式区域配置


