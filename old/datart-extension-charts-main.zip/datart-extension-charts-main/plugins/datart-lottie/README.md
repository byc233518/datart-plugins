## [Experimental] Lottie Animation Chart

- [x] datart version: **1.0.0**
- [x] status: **experimental**

![ZRender](./lottie-record.gif)

## 使用说明

## 资源

https://lottiefiles.com/web-player

https://lottiefiles.com/featured