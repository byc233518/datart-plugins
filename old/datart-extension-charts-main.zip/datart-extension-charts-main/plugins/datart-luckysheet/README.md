## [Experimental] 基于LuckySheet的图表

- [x] datart version: **1.0.0**
- [x] status: **experimental**

![LuckySheet](./experiment-luckysheet-demo.png）

## 使用说明

请参考官方文档： https://mengshukeji.github.io/LuckysheetDocs/guide/#steps-for-usage

### 数据区域配置

### 样式区域配置
