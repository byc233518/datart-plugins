## [Experimental] 滚动图表

- [x] datart version: **1.0.0-beta.1**
- [x] status: **experimental**

![滚动图表](./scroll-table-chart.png)

## 使用说明

### 数据区域配置
None
### 样式区域配置
- 可设置`开始延迟`、`运动方向`、`持续时间`、`间隔`、`悬停时暂停`、`是否连续`、`是否起点显示`
