## [Experimental] Three.js BingDunDun Sample

- [x] datart version: **1.0.0**
- [x] status: **experimental**

![ThreeJS](./bigndundun.png)

## 使用说明

### 数据区域配置

### 样式区域配置


