## [Experimental] Three.js Sample

- [x] datart version: **1.0.0**
- [x] status: **experimental**

![ThreeJS](./callada.gif)

## 使用说明

### 数据区域配置

### 样式区域配置


