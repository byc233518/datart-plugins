## [Experimental] EChart 人均寿命演变图

- [x] datart version: **1.0.0**
- [x] status: **experimental**

![时序图](./time-series-chart.png)

## 使用说明

### 数据区域配置
None
### 样式区域配置
None
