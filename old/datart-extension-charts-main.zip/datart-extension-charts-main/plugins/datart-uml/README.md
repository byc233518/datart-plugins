## [Experimental] 基于Mermaid的UML图

- [x] datart version: **1.0.0**
- [x] status: **experimental**

![时序图](./experiment-uml-chart.png)

## 使用说明

关于UML图插件的API使用，请参考Mermaid[官方文档和示例](https://mermaid-js.github.io/mermaid/#/)

### 数据区域配置

### 样式区域配置
- 代码设置：直接以Text文本的形式编辑数据，后期可以使用Monaco Code作为数据编辑器，目前是纯文本框。
- 水印设置：增加水印

