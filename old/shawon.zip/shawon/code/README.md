# datart-extension-charts
An extension repository to host datart plugin charts which is in experiment state not officially.

## How to use 
### 1. use iife type of chart plugin
Please run `yarn build` or `npm run build`, and get copy file from `dist` folder.

### 2. use as React Component
Please check the file in folder `plugins` 

 __NOTE: Plugin folder should be prefix as `datart-*` which could be automatic load when run `yarn build`__
