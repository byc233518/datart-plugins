import { DatartDvCharts } from "./datart-dv-chart";

export default DatartDvCharts;